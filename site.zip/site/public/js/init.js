skel.init({
	prefix: 'css/style',
	resetCSS: true,
	boxModel: 'border',
	grid: {
		gutters: 50
	},
	breakpoints: {
		'desktop': {
			range: '481-',
			containers: 1400
		}

	}
	
});